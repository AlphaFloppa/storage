import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import AdmissionSteps from './components/AdmissionSteps';
import LyceeLife from './components/LyceeLife';
import InfoSections from './components/InfoSections';
import Specialties from './components/Specialties';
import FooterCTA from './components/FooterCTA';
import './styles/global.css';

const LandingPage: React.FC = () => {
  return (
    <div className="landing-root">
      <Header />
      <Hero />
      <AdmissionSteps />
      <LyceeLife />
      <InfoSections />
      <Specialties />
      <FooterCTA />
    </div>
  );
};

export default LandingPage;
