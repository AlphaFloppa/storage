import React from 'react';
import './InfoSections.css';

/**
 * Images:
 *   фотки/image 263.png → public/images/info/distribution.jpg
 *   фотки/image 265.png → public/images/info/cost.jpg
 *   фотки/image 266.png → public/images/info/beyond.jpg
 */

interface InfoBlock {
  id: string;
  eyebrow: string;
  title: string;
  body: React.ReactNode;
  imgSrc: string;
  imgAlt: string;
  imgRight?: boolean;
}

const BLOCKS: InfoBlock[] = [
  {
    id: 'distribution',
    eyebrow: 'После учёбы',
    title: 'Распределение',
    body: (
      <>
        <p>
          Когда вы пройдёте все этапы отбора, у вас появится возможность выбрать специализацию.
          Это происходит после того, как вы попадёте к нам. Мы всегда помогаем
          определиться тем, кто ещё не знает, чем хочет заниматься — «кодом» или «дизайном», вы обязательно найдёте себя.
        </p>
      </>
    ),
    imgSrc: '/images/info/distribution.jpg',
    imgAlt: 'Студенты обсуждают распределение',
    imgRight: false,
  },
  {
    id: 'cost',
    eyebrow: 'Финансы',
    title: 'Сколько стоит обучение?',
    body: (
      <>
        <p>
          Обучение в лицее бесплатно для всех поступивших. Вы можете найти подробную
          информацию о стипендиях и социальной поддержке на сайте лицея в разделе
          финансовой помощи студентам.
        </p>
        <a href="#" className="info-block__link">
          Перейти на сайт
          <svg viewBox="0 0 16 16" fill="none" aria-hidden="true">
            <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </a>
      </>
    ),
    imgSrc: '/images/info/cost.jpg',
    imgAlt: 'Учебный процесс в лицее',
    imgRight: true,
  },
  {
    id: 'beyond',
    eyebrow: 'Внеурочная жизнь',
    title: 'За пределами учёбы',
    body: (
      <>
        <p>
          В лицее вы не просто учитесь — вы участвуете в хакатонах, олимпиадах
          и конференциях. У нас есть клуб «ИНФОТЕХ», где можно реализовывать
          собственные проекты, а также площадка для творческих инициатив.
        </p>
        <p>
          Каждый год лучшие студенты проходят стажировки в IT-компаниях города.
        </p>
      </>
    ),
    imgSrc: '/images/info/beyond.jpg',
    imgAlt: 'Внеклассные мероприятия лицея',
    imgRight: false,
  },
];

const InfoSections: React.FC = () => {
  return (
    <section className="info-sections" aria-label="Подробности об обучении">
      {BLOCKS.map((block, idx) => (
        <div
          key={block.id}
          id={block.id}
          className={`info-block${block.imgRight ? ' info-block--reverse' : ''}${idx % 2 !== 0 ? ' info-block--alt' : ''}`}
        >
          <div className="container info-block__inner">
            <div className="info-block__text">
              <p className="info-block__eyebrow">{block.eyebrow}</p>
              <h2 className="section-title info-block__title">{block.title}</h2>
              <div className="info-block__body">{block.body}</div>
            </div>
            <div className="info-block__media">
              <figure className="info-block__figure">
                <img
                  src={block.imgSrc}
                  alt={block.imgAlt}
                  loading="lazy"
                  className="info-block__img"
                />
              </figure>
            </div>
          </div>
        </div>
      ))}
    </section>
  );
};

export default InfoSections;
