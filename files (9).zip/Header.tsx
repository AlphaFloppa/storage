import React, { useState, useEffect } from 'react';
import './Header.css';

const Header: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header className={`site-header${scrolled ? ' site-header--scrolled' : ''}`}>
      <div className="container header-inner">
        <a href="/" className="logo" aria-label="ИНФОТЕХ — главная">
          <span className="logo-text">ИНФОТЕХ</span>
        </a>

        <nav className={`header-nav${menuOpen ? ' header-nav--open' : ''}`} aria-label="Основная навигация">
          <a href="#steps" className="header-nav__link" onClick={() => setMenuOpen(false)}>Поступление</a>
          <a href="#life" className="header-nav__link" onClick={() => setMenuOpen(false)}>Жизнь в лицее</a>
          <a href="#specialties" className="header-nav__link" onClick={() => setMenuOpen(false)}>Специальности</a>
          <a href="#steps" className="btn-cta btn-cta--sm" onClick={() => setMenuOpen(false)}>
            Узнать больше
          </a>
        </nav>

        <button
          className={`burger${menuOpen ? ' burger--open' : ''}`}
          aria-label={menuOpen ? 'Закрыть меню' : 'Открыть меню'}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen(v => !v)}
        >
          <span />
          <span />
          <span />
        </button>
      </div>
    </header>
  );
};

export default Header;
