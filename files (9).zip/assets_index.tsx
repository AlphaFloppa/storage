import React from 'react';
import { createRoot } from 'react-dom/client';
import LandingPage from './landing/LandingPage';

const rootElement = document.getElementById('app');
if (!rootElement) {
  throw new Error('Root element #app not found in the DOM.');
}

const root = createRoot(rootElement);
root.render(
  <React.StrictMode>
    <LandingPage />
  </React.StrictMode>
);
