import React from 'react';
import './Specialties.css';

/**
 * Specialty images from archive folder 2/:
 *   фотки/ 2/image 273.png  → public/images/spec/prog-1.jpg
 *   фотки/ 2/image 274.png  → public/images/spec/prog-2.jpg
 *   фотки/ 2/image 276.png  → public/images/spec/design-1.jpg
 *   фотки/ 2/image 278.png  → public/images/spec/design-2.jpg
 *   фотки/ 2/IMG_7178 2.png → public/images/spec/prog-3.jpg
 *   фотки/ 2/IMG_7187 2.png → public/images/spec/design-3.jpg
 */

interface Tag { label: string; active?: boolean; }
interface Specialty {
  id: string;
  name: string;
  eyebrow: string;
  description: string;
  additionalInfo: string;
  tags: Tag[];
  images: { src: string; alt: string }[];
}

const SPECIALTIES: Specialty[] = [
  {
    id: 'programming',
    name: 'Программирование',
    eyebrow: 'Информация о курсе',
    description:
      'Вы научитесь создавать программы и сервисы с нуля, работать в команде и применять современные инструменты разработки.',
    additionalInfo: 'Дополнительные предметы с 10-11 классах:',
    tags: [
      { label: 'Алгебра и начала анализа', active: true },
      { label: 'Информатика' },
      { label: 'Среды разработки', active: true },
      { label: 'Web-разработка' },
    ],
    images: [
      { src: '/images/spec/prog-1.jpg', alt: 'Занятие по программированию' },
      { src: '/images/spec/prog-2.jpg', alt: 'Работа над проектом' },
      { src: '/images/spec/prog-3.jpg', alt: 'Студенты-программисты' },
    ],
  },
  {
    id: 'design',
    name: 'Дизайн',
    eyebrow: 'Информация о курсе',
    description:
      'Вы освоите инструменты визуальной коммуникации, научитесь работать с брендингом, UI/UX и цифровой иллюстрацией.',
    additionalInfo: 'Дополнительные предметы с 10-11 классах:',
    tags: [
      { label: 'Basics дизайна', active: true },
      { label: 'Figma, Adobe Suite' },
      { label: 'Основы визуального мышления', active: true },
      { label: 'Дизайн интерфейсов' },
    ],
    images: [
      { src: '/images/spec/design-1.jpg', alt: 'Занятие по дизайну' },
      { src: '/images/spec/design-2.jpg', alt: 'Работа с макетами' },
      { src: '/images/spec/design-3.jpg', alt: 'Творческие проекты' },
    ],
  },
];

const Specialties: React.FC = () => {
  return (
    <section className="specialties-section" id="specialties" aria-label="Специальности">
      <div className="container">
        <p className="spec-eyebrow">Направления</p>
        <h2 className="section-title spec-main-title">Разделение на специальности</h2>
        <p className="spec-intro">
          В каждой группе не более чем по 15 специализирующихся учеников — это 5 специальных
          учеников в 9 классах и 10 специализирующихся студентов в 10–11 классах. Таким образом
          всего в каждом потоке может быть от 25 до 30 специализирующихся студентов.
        </p>
        <p className="spec-intro">
          В каждой группе по отдельной специализации будет педагог-куратор.
        </p>

        <div className="spec-tracks">
          {SPECIALTIES.map((spec) => (
            <article key={spec.id} className="spec-track" aria-label={`Специальность: ${spec.name}`}>
              <div className="spec-track__info">
                <h3 className="spec-track__name">{spec.name}</h3>
                <p className="spec-track__eyebrow">{spec.eyebrow}</p>
                <p className="spec-track__desc">{spec.description}</p>
                <p className="spec-track__add-label">{spec.additionalInfo}</p>
                <div className="spec-track__tags" role="list" aria-label="Предметы">
                  {spec.tags.map((tag, i) => (
                    <span
                      key={i}
                      role="listitem"
                      className={`spec-tag${tag.active ? ' spec-tag--active' : ''}`}
                    >
                      {tag.label}
                    </span>
                  ))}
                </div>
              </div>

              <div className="spec-track__gallery">
                {spec.images.map((img, i) => (
                  <figure key={i} className={`spec-img-card spec-img-card--${i + 1}`}>
                    <img src={img.src} alt={img.alt} loading="lazy" />
                  </figure>
                ))}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Specialties;
