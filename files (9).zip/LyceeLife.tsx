import React, { useRef } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';
import type { Swiper as SwiperType } from 'swiper';
import 'swiper/css';
import 'swiper/css/pagination';
import './LyceeLife.css';

/**
 * Image filenames map to files in public/images/life/
 * Copy images from archive:
 *   фотки/ 1/image 267.png   → public/images/life/life-1.jpg
 *   фотки/ 1/image 273.png   → public/images/life/life-2.jpg
 *   фотки/ 1/image 274.png   → public/images/life/life-3.jpg
 *   фотки/ 1/IMG_7160 2.png  → public/images/life/life-4.jpg
 *   фотки/ 1/IMG_7173 1.png  → public/images/life/life-5.jpg
 *   фотки/ 1/IMG_7174 1.png  → public/images/life/life-6.jpg
 *   фотки/ 1/IMG_7175 1.png  → public/images/life/life-7.jpg
 */
const SLIDES = [
  { src: '/images/life/life-1.jpg', alt: 'Студенты лицея' },
  { src: '/images/life/life-2.jpg', alt: 'Занятия в лицее' },
  { src: '/images/life/life-3.jpg', alt: 'Проект студентов' },
  { src: '/images/life/life-4.jpg', alt: 'Жизнь в лицее' },
  { src: '/images/life/life-5.jpg', alt: 'Команда лицея' },
  { src: '/images/life/life-6.jpg', alt: 'Мероприятие' },
  { src: '/images/life/life-7.jpg', alt: 'Творческий проект' },
];

const LyceeLife: React.FC = () => {
  const swiperRef = useRef<SwiperType | null>(null);

  return (
    <section className="life-section" id="life" aria-label="Жизнь в лицее">
      <div className="container life-top">
        <h2 className="section-title life-title">Жизнь в лицее</h2>
        <p className="life-description">
          Каждый день в лицее — это не только учёба, но и события,
          проекты и встречи. Ты будешь здесь своим — мы создаём среду,
          в которой интересно развиваться.
        </p>
      </div>

      <div className="life-slider-wrap">
        <Swiper
          modules={[Navigation, Pagination, Autoplay]}
          spaceBetween={16}
          slidesPerView={1.15}
          centeredSlides={false}
          loop={true}
          autoplay={{ delay: 3800, disableOnInteraction: false, pauseOnMouseEnter: true }}
          pagination={{ clickable: true, el: '.life-pagination' }}
          onSwiper={(swiper) => { swiperRef.current = swiper; }}
          breakpoints={{
            640: { slidesPerView: 1.6, spaceBetween: 20 },
            900: { slidesPerView: 2.2, spaceBetween: 24 },
            1200: { slidesPerView: 2.6, spaceBetween: 28 },
          }}
          className="life-swiper"
          aria-label="Галерея фотографий лицея"
        >
          {SLIDES.map((slide, i) => (
            <SwiperSlide key={i}>
              <figure className="life-slide">
                <img
                  src={slide.src}
                  alt={slide.alt}
                  loading={i === 0 ? 'eager' : 'lazy'}
                  className="life-slide__img"
                />
              </figure>
            </SwiperSlide>
          ))}
        </Swiper>

        <div className="life-controls">
          <button
            className="life-nav life-nav--prev"
            aria-label="Предыдущий слайд"
            onClick={() => swiperRef.current?.slidePrev()}
          >
            <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
              <path d="M12 4l-6 6 6 6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
          <div className="life-pagination" role="group" aria-label="Навигация по слайдам" />
          <button
            className="life-nav life-nav--next"
            aria-label="Следующий слайд"
            onClick={() => swiperRef.current?.slideNext()}
          >
            <svg viewBox="0 0 20 20" fill="none" aria-hidden="true">
              <path d="M8 4l6 6-6 6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        </div>
      </div>
    </section>
  );
};

export default LyceeLife;
