import React from 'react';
import './FooterCTA.css';

const FooterCTA: React.FC = () => {
  return (
    <footer className="footer-cta-section" aria-label="Призыв к действию и подвал">
      <div className="footer-cta-top">
        <div className="container footer-cta-content">
          <div className="footer-cta-text">
            <h2 className="footer-cta-title">
              Начни своё поступление<br />
              уже сейчас
            </h2>
            <p className="footer-cta-sub">
              Регистрация открыта. Займи своё место среди будущих IT-специалистов.
            </p>
            <a href="#" className="btn-cta footer-cta-btn">
              Узнать об экзамене для отбора
              <svg viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </a>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <div className="container footer-bottom-inner">
          <span className="footer-logo">ИНФОТЕХ</span>
          <nav className="footer-nav" aria-label="Ссылки в подвале">
            <a href="#steps" className="footer-nav__link">Поступление</a>
            <a href="#life" className="footer-nav__link">Жизнь в лицее</a>
            <a href="#specialties" className="footer-nav__link">Специальности</a>
          </nav>
          <span className="footer-copy">© {new Date().getFullYear()} ИНФОТЕХ</span>
        </div>
      </div>
    </footer>
  );
};

export default FooterCTA;
