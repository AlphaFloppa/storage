# ИНФОТЕХ — Лендинг. Инструкция по установке

## Структура файлов для создания

```
tracker-new/
├── assets/
│   ├── index.tsx                          ← ЗАМЕНИТЬ (содержимое из assets_index.tsx)
│   └── landing/
│       ├── LandingPage.tsx
│       ├── styles/
│       │   └── global.css
│       └── components/
│           ├── Header.tsx
│           ├── Header.css
│           ├── Hero.tsx
│           ├── Hero.css
│           ├── AdmissionSteps.tsx
│           ├── AdmissionSteps.css
│           ├── LyceeLife.tsx
│           ├── LyceeLife.css
│           ├── InfoSections.tsx
│           ├── InfoSections.css
│           ├── Specialties.tsx
│           ├── Specialties.css
│           ├── FooterCTA.tsx
│           └── FooterCTA.css
├── public/
│   └── images/
│       ├── hero-bg.jpg           ← из архива: фотки/image 263.png  (переименовать)
│       ├── info/
│       │   ├── distribution.jpg  ← фотки/image 265.png
│       │   ├── cost.jpg          ← фотки/image 266.png
│       │   └── beyond.jpg        ← фотки/ 1/image 267.png
│       ├── life/
│       │   ├── life-1.jpg        ← фотки/ 1/image 273.png
│       │   ├── life-2.jpg        ← фотки/ 1/image 274.png
│       │   ├── life-3.jpg        ← фотки/ 1/IMG_7160 2.png
│       │   ├── life-4.jpg        ← фотки/ 1/IMG_7173 1.png
│       │   ├── life-5.jpg        ← фотки/ 1/IMG_7174 1.png
│       │   ├── life-6.jpg        ← фотки/ 1/IMG_7175 1.png
│       │   └── life-7.jpg        ← фотки/ 2/image 273-1.png
│       └── spec/
│           ├── prog-1.jpg        ← фотки/ 2/image 273.png
│           ├── prog-2.jpg        ← фотки/ 2/image 274.png
│           ├── prog-3.jpg        ← фотки/ 2/IMG_7178 2.png
│           ├── design-1.jpg      ← фотки/ 2/image 276.png
│           ├── design-2.jpg      ← фотки/ 2/image 278.png
│           └── design-3.jpg      ← фотки/ 2/IMG_7187 2.png
├── src/
│   └── Controller/
│       └── LandingController.php ← СОЗДАТЬ
├── templates/
│   └── index.html.twig           ← ЗАМЕНИТЬ
├── package.json                  ← ЗАМЕНИТЬ / ОБНОВИТЬ
├── webpack.config.js             ← ЗАМЕНИТЬ
├── tsconfig.json                 ← ЗАМЕНИТЬ / ОБНОВИТЬ
└── postcss.config.js             ← СОЗДАТЬ
```

## Шаги установки

### 1. Скопируй все файлы компонентов
Скопируй папку `landing/` в `assets/`.

### 2. Замени assets/index.tsx
```tsx
import React from 'react';
import { createRoot } from 'react-dom/client';
import LandingPage from './landing/LandingPage';

const rootElement = document.getElementById('app');
if (!rootElement) throw new Error('Root element #app not found');
createRoot(rootElement).render(
  <React.StrictMode><LandingPage /></React.StrictMode>
);
```

### 3. Создай контроллер
Создай `src/Controller/LandingController.php` (код выше).

### 4. Обнови templates/index.html.twig
Используй шаблон из `index_html_twig.txt`.

### 5. Обнови конфиги
- `package.json` — добавь зависимость `"swiper": "^11.1.9"` и `@types/react`, `@types/react-dom`
- `webpack.config.js` — убедись что есть `.enableTypeScriptLoader()` и `.enableReactPreset()`
- `tsconfig.json` — убедись что `"jsx": "react-jsx"`
- Создай `postcss.config.js`

### 6. Добавь изображения
Распакуй архив `фотки.rar` и скопируй файлы в `public/images/` согласно таблице выше.
Переименуй файлы (убери пробелы, замени расширения если нужно).

### 7. Установка и сборка
```bash
npm install
npm run build
# или для разработки:
npm run watch
```

### 8. Symfony
```bash
composer install
php bin/console cache:clear
symfony serve
```

## NPM пакеты которые нужно добавить

```bash
npm install swiper
npm install --save-dev @types/react @types/react-dom
```

## Важные замечания

- Все изображения лежат в `public/images/` — они доступны по пути `/images/...` без `public/`
- Шрифт Geologica загружается с Google Fonts через CSS `@import` в `global.css`
- Слайдер Swiper подключён через npm, CSS импортируется прямо в компоненте `LyceeLife.tsx`
- Адаптивность готова для 320px–1440px+
- Компоненты используют обычный CSS (не CSS Modules, не Tailwind)
