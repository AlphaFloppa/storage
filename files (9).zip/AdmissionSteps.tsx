import React, { useState } from 'react';
import './AdmissionSteps.css';

interface Step {
  num: string;
  title: string;
  body: string;
  link?: string;
}

const STEPS: Step[] = [
  {
    num: '01',
    title: 'Регистрация',
    body: 'Зарегистрироваться в Личном кабинете поступающего можно на сайте. Внутри — подробное описание каждого этапа и отслеживание прогресса.',
    link: '#',
  },
  {
    num: '02',
    title: 'Подача документов',
    body: 'После регистрации в Личном кабинете открывается доступ к подаче документов. Прикрепляйте файлы можно в разделе «Подача документов».',
  },
  {
    num: '03',
    title: 'Экзамены',
    body: 'С помощью экзаменов мы поймём уровень знаний поступающего и сможем подобрать, предрасположен ли он больше к программированию или к дизайну.',
  },
  {
    num: '04',
    title: 'Собеседование',
    body: 'Финальный этап отбора — личная встреча с представителями приёмной комиссии. Мы хотим познакомиться с тобой ближе.',
  },
  {
    num: '05',
    title: 'Поступление',
    body: 'Поздравляем! После прохождения всех этапов ты получишь официальное уведомление о зачислении.',
  },
];

const AdmissionSteps: React.FC = () => {
  const [openStep, setOpenStep] = useState<string | null>('01');

  const toggle = (num: string) => {
    setOpenStep(prev => (prev === num ? null : num));
  };

  return (
    <section className="steps-section" id="steps" aria-label="Этапы поступления">
      <div className="container">
        <div className="steps-header">
          <div className="steps-header__left">
            <p className="steps-eyebrow">Как поступить</p>
            <h2 className="section-title">
              Готовься<br />
              к поступлению<br />
              уже сейчас
            </h2>
          </div>
          <div className="steps-header__right">
            <p className="steps-description">
              Для начала необходимо выбрать курс, «Подать заявку» — зарегистрируйтесь в Личном кабинете поступающего и следуйте инструкциям.
            </p>
            <a href="#" className="btn-cta steps-cta">
              Узнать об экзамене для отбора
              <svg viewBox="0 0 16 16" fill="none" aria-hidden="true">
                <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </a>
          </div>
        </div>

        <ol className="steps-list" aria-label="Шаги поступления">
          {STEPS.map((step) => {
            const isOpen = openStep === step.num;
            return (
              <li key={step.num} className={`step-item${isOpen ? ' step-item--open' : ''}`}>
                <button
                  className="step-item__header"
                  onClick={() => toggle(step.num)}
                  aria-expanded={isOpen}
                  aria-controls={`step-body-${step.num}`}
                >
                  <span className="step-item__num" aria-hidden="true">{step.num}</span>
                  <span className="step-item__title">{step.title}</span>
                  <span className="step-item__arrow arrow-icon" aria-hidden="true">
                    <svg viewBox="0 0 16 16" fill="none">
                      <path
                        d={isOpen ? 'M4 10l4-4 4 4' : 'M4 6l4 4 4-4'}
                        stroke="currentColor"
                        strokeWidth="1.5"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </span>
                </button>

                <div
                  id={`step-body-${step.num}`}
                  className="step-item__body"
                  role="region"
                  hidden={!isOpen}
                >
                  <p className="step-item__text">{step.body}</p>
                  {step.link && (
                    <a href={step.link} className="step-item__link">
                      Подробнее
                      <svg viewBox="0 0 16 16" fill="none" aria-hidden="true">
                        <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </a>
                  )}
                </div>
              </li>
            );
          })}
        </ol>
      </div>
    </section>
  );
};

export default AdmissionSteps;
