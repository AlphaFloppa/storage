import React from 'react';
import './Hero.css';

// The hero uses a photo background. Path relative to public/ folder in Symfony.
// Place image at: public/images/hero-bg.jpg
// (use one of the photos from the archive, e.g. image 263.png renamed)

const Hero: React.FC = () => {
  return (
    <section className="hero" aria-label="Главный баннер">
      <div className="hero__bg-overlay" />

      <div className="container hero__content">
        <div className="hero__text">
          <p className="hero__eyebrow">Лицей ИНФОТЕХ</p>
          <h1 className="hero__title">
            Узнай всё<br />
            и поступи к нам
          </h1>
          <p className="hero__subtitle">
            Мы готовим специалистов в области IT и дизайна.<br />
            Приёмная кампания открыта — зарегистрируйся и начни путь.
          </p>
          <a href="#steps" className="btn-cta hero__cta">
            Узнать об экзамене для отбора
            <svg viewBox="0 0 16 16" fill="none" aria-hidden="true">
              <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </a>
        </div>
      </div>

      <div className="hero__scroll-hint" aria-hidden="true">
        <span />
      </div>
    </section>
  );
};

export default Hero;
